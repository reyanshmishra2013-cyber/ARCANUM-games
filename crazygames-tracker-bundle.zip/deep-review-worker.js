/**
 * deep-review-worker.js
 *
 * A minimal Cloudflare Worker that lets your public "Submission Odds Machine"
 * page get a real AI opinion (description quality, screenshot content,
 * self-report consistency) WITHOUT ever exposing your Anthropic API key to
 * visitors. The key lives only as a Worker secret on Cloudflare's servers.
 *
 * ---------------------------------------------------------------------------
 * DEPLOY (one-time setup, ~5 minutes)
 * ---------------------------------------------------------------------------
 * 1. Install the Cloudflare CLI (if you don't have it):
 *      npm install -g wrangler
 *
 * 2. In an empty folder, put this file as `src/index.js` and create a
 *    `wrangler.toml` next to it:
 *
 *      name = "cga-review-proxy"
 *      main = "src/index.js"
 *      compatibility_date = "2024-01-01"
 *
 * 3. Log in and set your Anthropic key as a secret (never in the code):
 *      wrangler login
 *      wrangler secret put ANTHROPIC_API_KEY
 *      # paste your key (starts with sk-ant-...) when prompted
 *
 * 4. (Recommended) Restrict who can call it — edit ALLOWED_ORIGIN below to
 *    your site's exact origin, e.g. "https://yourdomain.com", instead of "*".
 *
 * 5. Deploy:
 *      wrangler deploy
 *
 *    Wrangler prints a URL like:
 *      https://cga-review-proxy.YOUR-SUBDOMAIN.workers.dev
 *
 * 6. Paste that URL into AI_CONFIG.proxyUrl near the top of the <script> in
 *    crazygames-tracker-free.html, and set AI_CONFIG.enabled = true.
 *
 * ---------------------------------------------------------------------------
 * COST & ABUSE NOTES (read before going live on a public page)
 * ---------------------------------------------------------------------------
 * - Every "Pull the Lever" click with AI enabled costs you a small amount of
 *   Anthropic API usage. That's normal, but it means a public page can be
 *   hit repeatedly by a bot to run up a bill.
 * - This Worker enforces a fixed max_tokens and rejects oversized images to
 *   bound per-call cost. It does NOT rate-limit by visitor — for a public
 *   page, add one of:
 *     - Cloudflare Turnstile (free CAPTCHA) in front of the submit button
 *     - Cloudflare Rate Limiting rules (dashboard, no code needed)
 *     - A Workers KV-based per-IP counter (ask me and I'll add it)
 * - Consider setting a monthly spend cap in your Anthropic console as a
 *   backstop regardless of what's in front of this Worker.
 */

const ALLOWED_ORIGIN = "*"; // tighten to your exact domain before going live, e.g. "https://yourdomain.com"
const MODEL = "claude-haiku-4-5-20251001"; // fast/cheap, vision-capable — swap to "claude-sonnet-5" for stronger judgment at higher cost
const MAX_IMAGE_BYTES = 4 * 1024 * 1024; // ~4MB base64 image cap, keeps cost/latency bounded
const MAX_DESC_CHARS = 2000;

const SYSTEM_PROMPT = `You are a strict QA reviewer for a browser game submission checklist (CrazyGames' Basic Launch requirements). You will be given a game's title, one-line pitch, gameplay description, and optionally a gameplay screenshot. Reply with ONLY a JSON object, no other text, no markdown fences, matching exactly this shape:

{
  "descriptionVerdict": "pass" | "warn" | "fail",
  "descriptionNote": "<one short sentence, <120 chars, on whether the description names real, specific, checkable gameplay mechanics vs. generic/vague/marketing language>",
  "screenshotVerdict": "pass" | "warn" | "fail" | "not_provided",
  "screenshotNote": "<one short sentence, <120 chars, on whether the image looks like real gameplay (not a placeholder, stock photo, splash screen, or unrelated image), its apparent quality, and PEGI-12 content concerns if any>",
  "consistencyFlag": true | false,
  "consistencyNote": "<one short sentence, <120 chars, empty string if consistencyFlag is false, explaining any contradiction between the stated title/pitch/description and what the screenshot actually shows>"
}

Be skeptical by default. Vague filler ("fun addictive game") should fail descriptionVerdict. A screenshot that's blank, a logo, a stock photo, or doesn't match the stated genre should fail screenshotVerdict and set consistencyFlag true. Do not soften your judgment to be encouraging — this is a pre-submission gate, not feedback for a student.`;

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders() });
    }
    if (request.method !== "POST") {
      return json({ error: "Only POST is supported" }, 405);
    }

    let body;
    try {
      body = await request.json();
    } catch {
      return json({ error: "Invalid JSON body" }, 400);
    }

    const title = String(body.title || "").slice(0, 200);
    const tagline = String(body.tagline || "").slice(0, 300);
    const desc = String(body.desc || "").slice(0, MAX_DESC_CHARS);
    const screenshotBase64 = typeof body.screenshotBase64 === "string" ? body.screenshotBase64 : null;
    const screenshotMediaType = typeof body.screenshotMediaType === "string" ? body.screenshotMediaType : "image/png";

    if (screenshotBase64 && screenshotBase64.length > MAX_IMAGE_BYTES) {
      return json({ error: "Screenshot too large for AI review (try a smaller/compressed image)" }, 413);
    }
    if (!desc) {
      return json({ error: "No description provided to review" }, 400);
    }

    const userContent = [
      {
        type: "text",
        text: `Title: ${title || "(none given)"}\nOne-line pitch: ${tagline || "(none given)"}\nGameplay description:\n${desc}`,
      },
    ];
    if (screenshotBase64) {
      userContent.push({
        type: "image",
        source: { type: "base64", media_type: screenshotMediaType, data: screenshotBase64 },
      });
    }

    let anthropicRes;
    try {
      anthropicRes = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "x-api-key": env.ANTHROPIC_API_KEY,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: MODEL,
          max_tokens: 300,
          system: SYSTEM_PROMPT,
          messages: [{ role: "user", content: userContent }],
        }),
      });
    } catch (err) {
      return json({ error: "Could not reach Anthropic API: " + err.message }, 502);
    }

    if (!anthropicRes.ok) {
      const errText = await anthropicRes.text().catch(() => "");
      return json({ error: `Anthropic API error (${anthropicRes.status}): ${errText.slice(0, 300)}` }, 502);
    }

    const data = await anthropicRes.json();
    const textBlock = (data.content || []).find((b) => b.type === "text");
    if (!textBlock) {
      return json({ error: "No text in Anthropic response" }, 502);
    }

    let parsed;
    try {
      const cleaned = textBlock.text.replace(/```json|```/g, "").trim();
      parsed = JSON.parse(cleaned);
    } catch {
      return json({ error: "Could not parse AI response as JSON", raw: textBlock.text.slice(0, 300) }, 502);
    }

    return json(parsed, 200);
  },
};

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": ALLOWED_ORIGIN,
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "content-type",
  };
}

function json(obj, status) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "content-type": "application/json", ...corsHeaders() },
  });
}
